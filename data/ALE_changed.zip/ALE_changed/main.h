#include "crf.h"
#include "IL/il.h"

#ifndef _WIN32
#include "std.cpp"
#include "filter.cpp"
#include "image.cpp"
#include "clustering.cpp"
#include "segmentation.cpp"
#include "feature.cpp"
#include "learning.cpp"
#include "potential.cpp"
#include "crf.cpp"
#include "dataset.cpp"
#endif
